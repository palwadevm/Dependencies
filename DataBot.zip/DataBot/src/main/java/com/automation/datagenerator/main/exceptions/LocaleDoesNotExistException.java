package com.automation.datagenerator.main.exceptions;

public class LocaleDoesNotExistException extends RuntimeException {
	/**
	 * ###################################################################################
	 * 
	 * @Type : long
	 * @Name : LocaleDoesNotExistException.java
	 * @Author : Vaijnath
	 * @Purpose : Error Handle
	 * @CreationDate : Jan 14, 2019 12:31:19 AM
	 * @Package : com.automation.datagenerator.main.dataUtils
	 *          ###################################################################################
	 **/
	private static final long serialVersionUID = 7435298075190372377L;
	
	public LocaleDoesNotExistException(String message) {
		super(message);
	}
}
