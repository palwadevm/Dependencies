package com.automation.datagenerator.main.rules;

import com.automation.datagenerator.main.DataGenerator;

public class Address {
	private final DataGenerator dataGenerator;
	
	public Address(DataGenerator dataGenerator) {
		this.dataGenerator = dataGenerator;
	}
	
	public String streetName() {
		return dataGenerator.dataService().resolve("address.street_name", this, dataGenerator);
	}
	
	public String streetAddressNumber() {
		return String.valueOf(dataGenerator.random().nextInt(1000));
	}
	
	public String streetAddress() {
		return dataGenerator.dataService().resolve("address.street_address", this, dataGenerator);
	}
	
	public String streetAddress(boolean includeSecondary) {
		String streetAddress = dataGenerator.dataService().resolve("address.street_address", this, dataGenerator);
		if (includeSecondary) {
			streetAddress = streetAddress + " " + secondaryAddress();
		}
		return streetAddress;
	}
	
	public String secondaryAddress() {
		return dataGenerator.generateDigits(dataGenerator.dataService().resolve("address.secondary_address", this, dataGenerator));
	}
	
	public String zipCode() {
		return dataGenerator.generateCharAndNumbers(dataGenerator.dataService().resolve("address.postcode", this, dataGenerator));
	}
	
	public String zipCodeByState(String stateAbbr) {
		return dataGenerator.dataService().resolve("address.postcode_by_state." + stateAbbr, this, dataGenerator);
	}
	
	public String streetSuffix() {
		return dataGenerator.dataService().resolve("address.street_suffix", this, dataGenerator);
	}
	
	public String streetPrefix() {
		return dataGenerator.dataService().resolve("address.street_prefix", this, dataGenerator);
	}
	
	public String citySuffix() {
		return dataGenerator.dataService().resolve("address.city_suffix", this, dataGenerator);
	}
	
	public String cityPrefix() {
		return dataGenerator.dataService().resolve("address.city_prefix", this, dataGenerator);
	}
	
	public String city() {
		return dataGenerator.dataService().resolve("address.city", this, dataGenerator);
	}
	
	public String cityName() {
		return dataGenerator.dataService().resolve("address.city_name", this, dataGenerator);
	}
	
	public String state() {
		return dataGenerator.dataService().resolve("address.state", this, dataGenerator);
	}
	
	public String stateAbbr() {
		return dataGenerator.dataService().resolve("address.state_abbr", this, dataGenerator);
	}
	
	public String firstName() {
		return dataGenerator.name().firstName();
	}
	
	public String lastName() {
		return dataGenerator.name().lastName();
	}
	
	public String latitude() {
		return String.format("%.8g", (dataGenerator.random().nextDouble() * 180) - 90);
	}
	
	public String longitude() {
		return String.format("%.8g", (dataGenerator.random().nextDouble() * 360) - 180);
	}
	
	public String timeZone() {
		return dataGenerator.dataService().resolve("address.time_zone", this, dataGenerator);
	}
	
	public String country() {
		return dataGenerator.dataService().resolve("address.country", this, dataGenerator);
	}
	
	public String countryCode() {
		return dataGenerator.dataService().resolve("address.country_code", this, dataGenerator);
	}
	
	public String buildingNumber() {
		return dataGenerator.generateDigits(dataGenerator.dataService().resolve("address.building_number", this, dataGenerator));
	}
	
	public String fullAddress() {
		return dataGenerator.dataService().resolve("address.full_address", this, dataGenerator);
	}
}
