package com.automation.datagenerator.main.rules;

import com.automation.datagenerator.main.DataGenerator;

public class PhoneNumber {
	private final DataGenerator dataGenerator;
	
	public PhoneNumber(DataGenerator dataGenerator) {
		this.dataGenerator = dataGenerator;
	}
	
	public String cellPhone() {
		return dataGenerator.generateDigits(dataGenerator.dataService().resolve("cell_phone.formats", this, dataGenerator));
	}
	
	public String phoneNumber() {
		return dataGenerator.generateDigits(dataGenerator.dataService().resolve("phone_number.formats", this, dataGenerator));
	}
}
