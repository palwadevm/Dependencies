package com.automation.datagenerator.main.rules;

import com.automation.datagenerator.main.DataGenerator;

public class Color {
	private final DataGenerator dataGenerator;
	
	public Color(DataGenerator data) {
		this.dataGenerator = data;
	}
	
	public String name() {
		return dataGenerator.dataService().resolve("color.name", this, dataGenerator);
	}
}
