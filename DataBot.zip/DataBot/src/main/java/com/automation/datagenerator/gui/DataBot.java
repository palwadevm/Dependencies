package com.automation.datagenerator.gui;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;

import com.automation.datagenerator.ValidExpressions;
import com.automation.datagenerator.main.DataGenerator;

public class DataBot {

	private JFrame frameMainWindow;
	private JTextField txtRows;
	private JTable tableDataFields;
	private JScrollPane scrollPaneDataFields;
	private JButton btnGenerateData;
	private JScrollPane scrollPane;
	private JTable tableGeneratedData;
	private JButton btnReset;
	private JMenuBar menuBar;
	private JMenu mnLoadFromProperties;
	private JButton btnRemoveRow;
	private JButton btnAddField;
	private JButton btnResetData;
	private DefaultTableModel modelData;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DataBot window = new DataBot();
					window.frameMainWindow.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public DataBot() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		Object[] fieldsColumns = new Object[] { "Field Name", "Type", "condition", "Option 1", "Option 2" };
		// Set Main Frame Window
		frameMainWindow = new JFrame();
		frameMainWindow.getContentPane().setBackground(SystemColor.window);
		frameMainWindow.setTitle("DataBot v1.0");
		frameMainWindow.setResizable(false);
		frameMainWindow.setBounds(100, 100, 1200, 700);
		frameMainWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// Create Content Pane
		frameMainWindow.setFont(new Font("Cantarell Light", Font.PLAIN, 10));
		frameMainWindow.getContentPane().setFont(new Font("Carnas Light", Font.PLAIN, 10));

		JLabel lblNumberOfRows = new JLabel("Number of rows to generate : ");
		lblNumberOfRows.setBounds(20, 16, 149, 13);
		lblNumberOfRows.setFont(new Font("Carnas Light", Font.BOLD, 10));
		frameMainWindow.getContentPane().setLayout(null);

		txtRows = new JTextField();
		txtRows.setFont(new Font("Carnas Light", Font.PLAIN, 10));
		txtRows.setBounds(182, 11, 192, 22);
		txtRows.setColumns(4);
		frameMainWindow.getContentPane().add(txtRows);

		scrollPaneDataFields = new JScrollPane();
		scrollPaneDataFields.setBounds(12, 36, 1176, 249);
		frameMainWindow.getContentPane().add(scrollPaneDataFields);
		DefaultTableModel model = new DefaultTableModel(new Object[][] { { null, null, null, null, null } },
				fieldsColumns);
		tableDataFields = new JTable(model);
		tableDataFields.setFont(new Font("Carnas Light", Font.PLAIN, 10));

		scrollPaneDataFields.setViewportView(tableDataFields);

		frameMainWindow.getContentPane().add(lblNumberOfRows);
		tableDataFields.setRowHeight(20);

		btnAddField = new JButton("Add Field");
		btnAddField.setBackground(SystemColor.window);
		btnAddField.setFont(new Font("Carnas Light", Font.BOLD, 10));
		btnAddField.setBounds(386, 12, 114, 18);
		btnAddField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				model.insertRow(tableDataFields.getRowCount(), new Object[] { "", "", "", "", "" });
			}
		});
		frameMainWindow.getContentPane().add(btnAddField);

		btnGenerateData = new JButton("Generate Data");
		btnGenerateData.setBackground(SystemColor.window);
		btnGenerateData.setFont(new Font("Carnas Light", Font.BOLD, 10));
		btnGenerateData.setBounds(22, 288, 147, 25);
		frameMainWindow.getContentPane().add(btnGenerateData);

		btnRemoveRow = new JButton("Remove Selected Row");
		btnRemoveRow.setFont(new Font("Carnas Light", Font.BOLD, 10));
		btnRemoveRow.setBackground(SystemColor.window);
		btnRemoveRow.setBounds(512, 11, 160, 18);
		frameMainWindow.getContentPane().add(btnRemoveRow);
		btnRemoveRow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// model.insertRow(tableDataFields.getRowCount(), new Object[] { "", "", "", "",
				// "" });
				model.removeRow(tableDataFields.getSelectedRow());
			}
		});

		btnReset = new JButton("Reset");
		btnReset.setFont(new Font("Carnas Light", Font.BOLD, 10));
		btnReset.setBackground(SystemColor.window);
		btnReset.setBounds(684, 12, 114, 18);
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				model.setRowCount(0);
			}
		});
		frameMainWindow.getContentPane().add(btnReset);

		scrollPane = new JScrollPane();
		scrollPane.setBounds(12, 325, 1176, 314);
		frameMainWindow.getContentPane().add(scrollPane);

		tableGeneratedData = new JTable();
		modelData = new DefaultTableModel();
		scrollPane.setViewportView(tableGeneratedData);

		menuBar = new JMenuBar();
		menuBar.setFont(new Font("Carnas Light", Font.BOLD, 10));
		frameMainWindow.setJMenuBar(menuBar);

		mnLoadFromProperties = new JMenu("Load From Properties File(tbd)");
		mnLoadFromProperties.setEnabled(false);
		mnLoadFromProperties.setFont(new Font("Carnas Light", Font.PLAIN, 10));
		menuBar.add(mnLoadFromProperties);
		tableGeneratedData.setAutoscrolls(true);
		tableGeneratedData.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

		btnResetData = new JButton("Reset Data");
		btnResetData.setFont(new Font("Carnas Light", Font.BOLD, 10));
		btnResetData.setBackground(SystemColor.window);
		btnResetData.setBounds(182, 287, 147, 25);
		btnResetData.setEnabled(false);
		frameMainWindow.getContentPane().add(btnResetData);
		// Add Data Fields Table
		tableDataFields.getModel().addTableModelListener(new TableModelListener() {

			@Override
			public void tableChanged(TableModelEvent e) {
				// TODO Auto-generated method stub
				List<String> resultsColumns = new ArrayList<String>();
				for (int iRow = 0; iRow < tableDataFields.getModel().getRowCount(); iRow++) {
					resultsColumns.add(String.valueOf(tableDataFields.getModel().getValueAt(iRow, 0)));
				}
				System.out.println(resultsColumns.toArray());
				modelData = new DefaultTableModel(new Object[][] { { "", "" } }, resultsColumns.toArray());
				tableGeneratedData.setModel(modelData);
			}
		});

		btnResetData.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				tableDataFields.setEnabled(true);
				btnResetData.setEnabled(false);
				btnReset.setEnabled(true);
				btnAddField.setEnabled(true);
				btnRemoveRow.setEnabled(true);
			}
		});
		btnGenerateData.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				tableDataFields.setEnabled(false);
				btnResetData.setEnabled(true);
				btnReset.setEnabled(false);
				btnAddField.setEnabled(false);
				btnRemoveRow.setEnabled(false);
				try {
					generateData();
				} catch (ParseException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}

			private void generateData() throws ParseException {
				String strRows = txtRows.getText();
				String data = null;
				DataGenerator dataGenerator = new DataGenerator();
				Long dataCount = strRows.equalsIgnoreCase("") ? Long.parseLong("0") : Long.parseLong(strRows);
				String name = "", type = "", condition = "", option1 = "", option2 = "";
				Pattern dependencyRegex = Pattern.compile("\\$\\{[A-Za-z0-9 ]+\\}");

				for (Long iCounter = (long) 0; iCounter < dataCount; iCounter++) {
					Map<String, String> dataArray = new HashMap<String, String>();
					for (int iRow = 0; iRow < tableDataFields.getRowCount(); iRow++) {
						name = String.valueOf(tableDataFields.getValueAt(iRow, 0));
						type = String.valueOf(tableDataFields.getValueAt(iRow, 1));
						condition = String.valueOf(tableDataFields.getValueAt(iRow, 2));
						option1 = String.valueOf(tableDataFields.getValueAt(iRow, 3));
						option2 = String.valueOf(tableDataFields.getValueAt(iRow, 4));
						for (String value : new String[] { condition, option1, option2 }) {
							Matcher match = dependencyRegex.matcher(value);
							while (match.find()) {
								condition = condition.replace(match.group(0), dataArray
										.get(match.group(0).replace("$", "").replace("{", "").replace("}", "")));
							}
						}
						data = "";
						switch (ValidExpressions.fromString(type)) {
						case DataRelation:
							data = condition;
							break;
						case DataDictionary:
							data = dataGenerator.parseExpression(option1);
							break;
						case SSNNumber:
							data = dataGenerator.ssn_number().ssnValid();
							break;
						case Dates:
							switch (condition.trim().toLowerCase()) {
							case "past date after":
								data = String.valueOf(dataGenerator.getDateTime()
										.between(new SimpleDateFormat("MM/dd/yyyy").parse(option1), new Date()));
								break;
							case "future date before":
								data = String.valueOf(dataGenerator.getDateTime().between(new Date(),
										new SimpleDateFormat("MM/dd/yyyy").parse(option1)));
								break;
							case "date between":
								data = String.valueOf(dataGenerator.getDateTime().between(
										new SimpleDateFormat("MM/dd/yyyy").parse(option1),
										new SimpleDateFormat("MM/dd/yyyy").parse(option2)));
								break;
							case "future date":
								data = String.valueOf(dataGenerator.getDateTime().future(10 * 360, TimeUnit.DAYS));
								break;
							case "past date":
								data = String.valueOf(dataGenerator.getDateTime().past(10 * 360, TimeUnit.DAYS));
								break;
							default:
								data = "invalid condition";
								break;
							}
							data = String.valueOf(dataGenerator.getDateTime().future(100, TimeUnit.DAYS));
							break;
						case Expression:
							data = dataGenerator.parseExpression(condition);
							break;
						case RegularExpression:
							data = dataGenerator.generateStringForRegEx(condition);
							break;
						case Numbers:
							switch (condition.trim().toLowerCase()) {
							case "between":
								data = String.valueOf(dataGenerator.number().numberBetween(Long.parseLong(option1),
										Long.parseLong(option2)));
								break;
							case "greater than":
								data = String.valueOf(String.valueOf(
										dataGenerator.number().numberBetween(Long.parseLong(option1), Long.MAX_VALUE)));
								break;
							case "less than":
								data = String.valueOf(dataGenerator.number().numberBetween(0, Long.parseLong(option1)));
								break;
							default:
								data = String.valueOf(dataGenerator.number().randomNumber());
								break;
							}
							break;
						case Format:
							data = dataGenerator.generateCharAndNumbers(condition);
							break;
						default:
							data = "invalid type";
							break;
						}
						System.out.println(name + " - " + data);
						dataArray.put(name, data);
					}
					// tableGeneratedData.getModel().
					String[] dataModel = new String[dataArray.values().size()];
					for (int iRow = 0; iRow < tableDataFields.getRowCount(); iRow++) {
						name = String.valueOf(tableDataFields.getValueAt(iRow, 0));
						dataModel[iRow] = dataArray.get(name);
					}
					modelData.addRow(dataModel);
				}
			}
		});

	}
}
