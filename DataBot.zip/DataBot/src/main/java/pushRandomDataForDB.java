import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import com.automation.datagenerator.main.DataGenerator;

/**
 * ###################################################################################
 * 
 * @Filename : pushRandomDataForDB.java
 * @Author : Vaijnath @time 1:11:49 PM
 * @Purpose : TODO
 * @CreationDate : Feb 2, 2019
 * @Package :
 *          ###################################################################################
 **/

/**
 * ###################################################################################
 * 
 * @Name : pushRandomDataForDB
 * @Author : Vaijnath
 * @Purpose : TODO
 * @CreationDate : Feb 2, 2019 1:11:49 PM
 * @Package :
 *          ###################################################################################
 **/
public class pushRandomDataForDB {
	
	/**
	 * ###################################################################################
	 * 
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * 
	 * @Name : main
	 * @Purpose : TODO
	 * @Parameters : @param args
	 * @ReturnType : void
	 * @Author : Vaijnath
	 * @CreationDate : Feb 2, 2019 1:11:49 PM
	 * @Modification :
	 *               ###################################################################################
	 **/
	public static void main(String[] args) throws SQLException {
		Connection conn = null;
		Connection oracleConn = null;
		try {
			String dbURL = "jdbc:sqlserver://datasource1.cd0ta02os5b7.ap-south-1.rds.amazonaws.com\\datasource1:1433;database=dbo";
			String dbOracle = "jdbc:oracle:thin:@orcl.cd0ta02os5b7.ap-south-1.rds.amazonaws.com:1521:ORCL";
			
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			Properties properties = new Properties();
			properties.put("user", "palwadevm");
			properties.put("password", "VP$yne55");
			conn = DriverManager.getConnection(dbURL, properties);
			Statement m_Statement = conn.createStatement();
			Class.forName("oracle.jdbc.driver.OracleDriver");
			oracleConn = DriverManager.getConnection(dbOracle, properties);
			Statement o_Statement = oracleConn.createStatement();
			System.out.println(conn.isValid(2) + " - " + oracleConn.isValid(2));
			int iRecords = 1000000;
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
			SimpleDateFormat format2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			DataGenerator dataGenerator = new DataGenerator();
			String sInsertQuery = "insert into UsersInfo (UserId,SSNNumber,FirstName, LastName, Salary, DateOfJoining, IsActive, LastLoginDate) VALUES ";
			System.out.println("UserId,SSNNumber,FirstName, LastName, Salary, DateOfJoining, IsActive, LastLoginDate");
			String sOracleQuery = "INSERT ALL ";
			for (int iCount = 1; iCount <= iRecords; iCount++) {
				int userId = dataGenerator.number().numberBetween(500, 87989875);
				String ssnNumber = dataGenerator.ssn_number().ssnValid();
				String firstName = dataGenerator.name().firstName();
				String lastName = dataGenerator.name().lastName();
				int salary = dataGenerator.number().numberBetween(10000, 999999999);
				Date joiningDate = dataGenerator.getDateTime().past(6 * 365, TimeUnit.DAYS);
				int isActive = dataGenerator.number().numberBetween(0, 2);
				Date loginDate = dataGenerator.getDateTime().past(6 * 365, TimeUnit.DAYS);
				sInsertQuery = sInsertQuery + "(" + userId + ", '" + ssnNumber + "', '" + firstName + "', '" + lastName + "', " + salary + ", '" + format.format(joiningDate) + "', " + isActive + "	, '" + format.format(loginDate) + "' )";
				sOracleQuery = sOracleQuery + "INTO PALWADEVM.USERS (USERID, SSNNUMBER, FIRSTNAME, LASTNAME, SALARY, DATEOFJOINING, ISACTIVE, LASTLOGINDATE) VALUES " + "(" + userId + ", '" + ssnNumber + "', '" + firstName + "', '" + lastName + "', '" + salary + "', TO_DATE('"
						+ format2.format(joiningDate) + "', 'YYYY-MM-DD HH24:MI:SS'), " + isActive + "	, TO_DATE('" + format2.format(loginDate) + "', 'YYYY-MM-DD HH24:MI:SS') )";
				System.out.println(userId + ", " + ssnNumber + ", " + firstName + ", " + lastName + "', " + salary + ", " + format.format(joiningDate) + ", " + isActive + "	, " + format.format(loginDate)  );
				if (iCount % 500 == 0 || iCount == iRecords) {
					
					System.out.println(sInsertQuery + "\n" + sOracleQuery + " SELECT * FROM dual");
					m_Statement.executeUpdate(sInsertQuery);
					o_Statement.executeUpdate(sOracleQuery + " SELECT * FROM dual");
					sInsertQuery = "insert into UsersInfo (UserId,SSNNumber,FirstName, LastName, Salary, DateOfJoining, IsActive, LastLoginDate) VALUES ";
					sOracleQuery = "INSERT ALL ";
					//					System.err.println("Inserted Records Count : " + iCount);
					
				} else {
					sInsertQuery = sInsertQuery + ",";
				}
			}
			
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			//			conn.close();
			//			oracleConn.close();
			System.out.println("-------------------Complete---------------------------");
			
		}
		
	}
	
}
